
Fs=16; %sampling frequency in Hertz or samples/second
t_start=-5; % start time in seconds
t_end=5; 
t=t_start:1/Fs:t_end;

%% Aliasing effect
f0=14;  % sinusoid signal frequency in Hertz
Omega_0=2*pi*f0;% frequency in radians per second
x=cos(Omega_0*t);

x_fft=fft(x); % taking Fast Fourier transform
x_fft=fftshift(x_fft); % traslating

%% time domain plot
stem(t,x) 
grid

%% frequency domain plot
N=length(x); % axis normalization
f=-Fs/2+Fs/N:Fs/N:(Fs/2);
f1=0:Fs/N:(Fs/2);
f2=-(Fs/2-Fs/N):Fs/N:0;
f=[f2 f1];
w=2*pi*f/Fs;

figure
subplot(311)
plot(w,abs(x_fft))
xlabel('frequency in radians/sample')
ylabel('amplitude')
grid

subplot(312)
plot(f,abs(x_fft))
xlabel('frequency in Hertz')
ylabel('amplitude')
grid

subplot(313)
plot(f,angle(x_fft))
xlabel('frequency in Hertz')
ylabel('angle in radians')
grid