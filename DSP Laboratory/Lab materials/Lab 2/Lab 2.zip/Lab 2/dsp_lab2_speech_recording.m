
% Record your voice for 10 seconds.
Fs=16000;
recObj = audiorecorder(Fs,8,1);
disp('Start speaking.')
recordblocking(recObj, 10);
disp('End of Recording.');

%Play back the recording.
play(recObj);

%Store data in double-precision array.
myRecording = getaudiodata(recObj);

%Plot the waveform.
plot(myRecording);

% save the waveform
save myRecording myRecording;

% load the data
load myRecording;

% time domain and frequency domain plot
x=myRecording;
t=0:1/Fs:10-1/Fs;

x_fft=fft(x); % taking Fast Fourier transform
x_fft=fftshift(x_fft); % traslating

N=length(x); % axis normalization
f=-Fs/2:Fs/N:(Fs/2-1/N);

subplot(2,1,1)
plot(t',x)
xlabel('time in seconds')
grid

subplot(2,1,2)
plot(f',abs(x_fft))
xlabel('frequency in Hz')
grid

