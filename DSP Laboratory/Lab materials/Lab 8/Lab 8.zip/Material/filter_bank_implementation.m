function filter_bank_implementation()

%% delta signal as an input
inp=[1 zeros(1,10)];

%% analysis filter bank
[ana_lp,ana_hp]=analysis_fb(inp);

%% synthesis filter bank
[syn_lp,syn_hp]=synthesis_fb(ana_lp,ana_hp);

%% add the two outputs
output=syn_lp+syn_hp;

%% plot the input and output result, what do you observe
stem(inp)
hold on 
stem(output)

end

%% analysis filter bank
% your task is to implemnt analysis filter bank efficiently
function [lp,hp]=analysis_fb(inp)
% input is the signal to the analysis filter bank
% lp is the output of the low pass section of the analysis filter bank
% hp is the output of the high pass section of the analysis filter bank

end

%% synthesis filter bank
function [lp_out,hp_out]=synthesis_fb(lp,hp)

% lp is the input to the low pass section of the synthesis filter bank
% hp is the input to the high pass section of the synthesis filter bank

% lp_out is the output of the low pass section of the synthesis filter bank
% hp_out is the output of the high pass section of the synthesis filter bank


end