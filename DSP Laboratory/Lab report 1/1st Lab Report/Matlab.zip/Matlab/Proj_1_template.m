%% Project 1: Time-Delay Estimation in GNSS %%
% you do not need the code file %

%% Load measurements: received signal
load('proj_1_sample.mat');

%% Correlation
% sampling rate
f=1.023e6;

% Calculation
% Here goes your code



%% Please print your result
